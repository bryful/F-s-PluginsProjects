﻿#include "CellEmboss.h"


// --- ビット深度ごとの型変換を吸収するヘルパー ---
inline PF_Pixel NF_To8(PF_Pixel c) { return c; }
inline PF_Pixel NF_To8(PF_Pixel16 c) { return NF_Pixel16To8(c); }
inline PF_Pixel NF_To8(PF_PixelFloat c) { return NF_Pixel32To8(c); }

template <typename T> struct ECTraits;

template <> struct ECTraits<PF_Pixel8> {
	typedef A_u_char comp;
	static inline comp half() { return 128; }
	static inline comp max_C() { return 255; }
	//static inline comp clamp(float v) { return (comp)AE_CLAMP(v + 0.5f, 0, 255); }
};

template <> struct ECTraits<PF_Pixel16> {
	typedef A_u_short comp;
	static inline comp half() { return 16384; } // AE 16bitは32768が上限
	static inline comp max_C() { return 32768; }
	//static inline comp clamp(float v) { return (comp)AE_CLAMP(v + 0.5f, 0, 32768); }
};

template <> struct ECTraits<PF_PixelFloat> {
	typedef PF_FpShort comp;
	static inline comp half() { return 0.5f; }
	static inline comp max_C() { return 1.0f; }
	//static inline comp clamp(float v) { return (comp)v; } // Floatは基本クランプ不要
};

// テンプレート用の情報を保持する構造体
template <typename T>
struct SPInfo {
	A_long		mode;
	A_long		count;
	PF_Pixel	target_colors[SP_COLOR_TABLE_MAX];
	//T			new_colors[SP_COLOR_TABLE_MAX];
	//T			newColor;
};

//-------------------------------------------------------------------------------------------------
// テンプレート化したピクセルサンプリング関数
//-------------------------------------------------------------------------------------------------
template<typename PixelType, typename AlphaType>
static PF_Err
EmbossColorise_Template(
	refconType	refcon,
	A_long		xL,
	A_long		yL,
	PixelType* inP,
	PixelType* outP,
	AlphaType maxValue)
{
	PF_Err			err = PF_Err_NONE;
	ParamInfo* infoP = reinterpret_cast<ParamInfo*>(refcon);
	if (outP->red == 0)
	{
		*outP = { 0,0,0,0 };
		return err;
	}

	PixelType colHI;
	PixelType colLO;

	if constexpr (std::is_same_v<PixelType, PF_Pixel>) {
		colHI = infoP->colorHi;
		colLO = infoP->colorLo;
	}
	else if constexpr (std::is_same_v<PixelType, PF_Pixel16>) {
		colHI = infoP->colorHi16;
		colLO = infoP->colorLo16;
	}
	else {
		colHI = infoP->colorHi32;
		colLO = infoP->colorLo32;
	}
	if (infoP->mode == 1)
	{
		// ハイライト
		outP->alpha = outP->green;
		outP->red =  colHI.red;
		outP->green = colHI.green;
		outP->blue = colHI.blue;
	}
	else if (infoP->mode == 2)
	{
		outP->alpha = outP->blue;
		outP->red = colLO.red;
		outP->green = colLO.green;
		outP->blue = colLO.blue;
	}
	else if (infoP->mode == 3)
	{
		outP->alpha = maxValue -  outP->green;
		outP->red = colHI.red;
		outP->green = colHI.green;
		outP->blue = colHI.blue;
	}

	return err;
}
// 8ビット用ラッパー
static PF_Err
EmbossColorise8(
	refconType	refcon,
	A_long		xL,
	A_long		yL,
	PF_Pixel* inP,
	PF_Pixel* outP)
{
	return EmbossColorise_Template<PF_Pixel, A_u_char>(refcon, xL, yL, inP, outP, PF_MAX_CHAN8);
}

//-------------------------------------------------------------------------------------------------
// 16ビット用ラッパー
static PF_Err
EmbossColorise16(
	refconType	refcon,
	A_long		xL,
	A_long		yL,
	PF_Pixel16* inP,
	PF_Pixel16* outP)
{
	return EmbossColorise_Template<PF_Pixel16, A_u_short>(refcon, xL, yL, inP, outP, PF_MAX_CHAN16);
}

//-------------------------------------------------------------------------------------------------
// 32ビット用ラッパー
static PF_Err
EmbossColorise32(
	refconType	refcon,
	A_long		xL,
	A_long		yL,
	PF_PixelFloat* inP,
	PF_PixelFloat* outP)
{
	return EmbossColorise_Template<PF_PixelFloat, PF_FpShort>(refcon, xL, yL, inP, outP, 1.0f);
}

//-------------------------------------------------------------------------------------------------
PF_Err EmbossColoriseFilter(
	NF_AE* ae,
	ParamInfo* infoP
)
{
	PF_Err err = PF_Err_NONE;

	switch (ae->pixelFormat()) {
	case PF_PixelFormat_ARGB128:
	{
		ae->suitesP->IterateFloatSuite2()->iterate(
			ae->in_data,
			0,
			ae->output->height,
			ae->input,
			NULL,
			infoP, 
			EmbossColorise32,
			ae->output);
	}
	break;

	case PF_PixelFormat_ARGB64:
	{
		ae->suitesP->Iterate16Suite2()->iterate(
			ae->in_data,
			0,
			ae->output->height,
			ae->input,
			NULL,
			infoP,
			EmbossColorise16,
			ae->output);
	}
	break;

	case PF_PixelFormat_ARGB32:
	{
		ae->suitesP->Iterate8Suite2()->iterate(
			ae->in_data,
			0,
			ae->output->height,
			ae->input,
			NULL,
			infoP,
			EmbossColorise8,
			ae->output);
	}
	break;
	}
	return err;
}