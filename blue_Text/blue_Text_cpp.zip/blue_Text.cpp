﻿//-----------------------------------------------------------------------------------
/*
	F's Plugins for VS2010/VS2012
*/
//-----------------------------------------------------------------------------------


#include "blue_Text.h"
#include <string>


//-------------------------------------------------------------------------------------------------
//AfterEffextsにパラメータを通達する
//Param_Utils.hを参照のこと
static PF_Err ParamsSetup (
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output)
{
	PF_Err			err = PF_Err_NONE;
	PF_ParamDef		def;
	AEFX_CLR_STRUCT(def);
	PF_ADD_SLIDER(STR_RADIUS,	//パラメータの名前
		0, 		//数値入力する場合の最小値
		1000,		//数値入力する場合の最大値
		0,		//スライダーの最小値 
		100,		//スライダーの最大値
		0,		//デフォルトの値
		ID_RADIUS
	);




	//----------------------------------------------------------------
	out_data->num_params = 	ID_NUM_PARAMS; 

	return err;
}
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
static PF_Err
HandleChangedParam(
	PF_InData					*in_data,
	PF_OutData					*out_data,
	PF_ParamDef					*params[],
	PF_LayerDef					*outputP,
	PF_UserChangedParamExtra	*extraP)
{
	PF_Err				err = PF_Err_NONE;
	
	
	return err;
}
//-----------------------------------------------------------------------------------
static PF_Err
QueryDynamicFlags(	
	PF_InData		*in_data,	
	PF_OutData		*out_data,	
	PF_ParamDef		*params[],	
	void			*extra)	
{
	PF_Err 	err = PF_Err_NONE;
	
	return err;
}

/* --- 1. 水平ボックスブラー (行単位スレッド処理) --- */
static PF_Err BoxBlurH16(
	void* refcon, 
	A_long x, 
	A_long y, 
	PF_Pixel16* in, 
	PF_Pixel16* out) 
{
	if (x != 0) return PF_Err_NONE; // 行単位処理なので y は常に 0
	BlurInfo* bi = (BlurInfo*)refcon;
	A_long width = bi->src->width;
	A_long r = bi->radius;
	if (r <= 0) return PF_Err_NONE;

	A_u_long sumR = 0, sumG = 0, sumB = 0, sumA = 0;
	A_long window = (r * 2) + 1;

	// 現在の行の先頭アドレスを取得
	PF_Pixel16* src_row = (PF_Pixel16*)((char*)bi->src->data + (y * bi->src->rowbytes));
	PF_Pixel16* dst_row = out; // iterateにより現在の行の先頭が渡される

	// 初期ウィンドウの合計（端はクランプ）
	for (A_long i = -r; i <= r; i++) {
		PF_Pixel16* p = src_row + AE_CLAMP(i, 0, width - 1);
		sumR += p->red; sumG += p->green; sumB += p->blue; sumA += p->alpha;
	}

	// スライディングウィンドウ計算
	for (A_long i = 0; i < width; i++) {
		dst_row[i].red = (A_u_short)(sumR / window);
		dst_row[i].green = (A_u_short)(sumG / window);
		dst_row[i].blue = (A_u_short)(sumB / window);
		dst_row[i].alpha = (A_u_short)(sumA / window);

		A_long left = AE_CLAMP(i - r, 0, width - 1);
		A_long right = AE_CLAMP(i + r + 1, 0, width - 1);

		sumR += (src_row[right].red - src_row[left].red);
		sumG += (src_row[right].green - src_row[left].green);
		sumB += (src_row[right].blue - src_row[left].blue);
		sumA += (src_row[right].alpha - src_row[left].alpha);
	}
	return PF_Err_NONE;
}

/* --- 2. 垂直ボックスブラー (列単位スレッド処理) --- */
static PF_Err BoxBlurV16(
	void* refcon,
	A_long x,          // AEから渡される「現在の列番号」
	A_long y,          // 0 が渡される
	PF_Pixel16* in,    // 使用しない（outからベースを計算するため）
	PF_Pixel16* out)   // 使用しない（計算が狂う原因になるため）
{
	if (y != 0) return PF_Err_NONE; // 列単位処理なので x は常に 0
	BlurInfo* bi = (BlurInfo*)refcon;
	
	PF_EffectWorld* dst = bi->src; // 構造体に output のポインタを入れておく
	A_long height = dst->height;
	A_long r = bi->radius;
	A_long window = (r * 2) + 1;
	A_long stride = dst->rowbytes / sizeof(PF_Pixel16);

	// 【重要】AEから渡される out ではなく、ベースポインタから自力で x 列目の先頭を計算
	PF_Pixel16* col_top = (PF_Pixel16*)((char*)dst->data + (x * sizeof(PF_Pixel16)));

	A_u_long sumR = 0, sumG = 0, sumB = 0, sumA = 0;

	// 1. 初期のウィンドウ合計（垂直方向）
	for (A_long i = -r; i <= r; i++) {
		PF_Pixel16* p = col_top + (AE_CLAMP(i, 0, height - 1) * stride);
		sumR += p->red; sumG += p->green; sumB += p->blue; sumA += p->alpha;
	}
	// 2. 列を下に向かってスライディングウィンドウで埋める
	for (A_long i = 0; i < height; i++) {
		PF_Pixel16* target = col_top + (i * stride);
		target->red = (A_u_short)(sumR / window);
		target->green = (A_u_short)(sumG / window);
		target->blue = (A_u_short)(sumB / window);
		target->alpha = (A_u_short)(sumA / window);

		A_long top = AE_CLAMP(i - r, 0, height - 1);
		A_long bottom = AE_CLAMP(i + r + 1, 0, height - 1);

		sumR += (col_top + bottom * stride)->red - (col_top + top * stride)->red;
		sumG += (col_top + bottom * stride)->green - (col_top + top * stride)->green;
		sumB += (col_top + bottom * stride)->blue - (col_top + top * stride)->blue;
		sumA += (col_top + bottom * stride)->alpha - (col_top + top * stride)->alpha;
	}
	return PF_Err_NONE;
}
//-------------------------------------------------------------------------------------------------
static PF_Err GetParams(CFsAE *ae, ParamInfo *infoP)
{
	PF_Err		err 		= PF_Err_NONE;

	//
	ERR(ae->GetADD(ID_RADIUS, &infoP->radius));

	return err;
}
//-------------------------------------------------------------------------------------------------
static PF_Err 
Exec(CFsAE* ae, ParamInfo* infoP)
{
	PF_Err err = PF_Err_NONE;
	BlurInfo bi;
	bi.radius = infoP->radius; // 半径を取得
	bi.src = ae->output; // 出力バッファをそのまま加工

	ae->CopyInToOut();
	if (bi.radius > 0) {
		PF_Rect rect;
		rect.top = 0;
		rect.left = 0;
		rect.right = 1;
		rect.bottom = ae->output->height;
		if (!err) {
			switch (ae->pixelFormat()) {
			case PF_PixelFormat_ARGB32:
				/*err = ae->suitesP->Iterate8Suite1()->iterate(
					in_data,
					0, 
					output->height, 
					NULL, 
					NULL, 
					&info,
					reinterpret_cast<PF_Err(*)(void*, A_int16, A_int16, PF_Pixel8*, PF_Pixel8*)>(TargetGradRadialIterator<PF_Pixel8, A_u_char>),
					output);*/
				break;

			case PF_PixelFormat_ARGB64:
				for (int n = 0; n < 3; n++) {
					ERR(ae->suitesP->Iterate16Suite1()->iterate(
						ae->in_data, 
						0, 
						ae->output->height, 
						ae->output, 
						NULL,
						&bi, 
						reinterpret_cast<PF_Err(*)(void*, A_long, A_long, PF_Pixel16*, PF_Pixel16*)>(BoxBlurH16),
						ae->output));
				}
				rect.top = 0;
				rect.left = 0;
				rect.right = ae->output->width;
				rect.bottom = 1;
				// ガウス近似：垂直3回 (引数にwidthを渡して列単位でスレッド化)
				for (int n = 0; n < 3; n++) {
					ERR(ae->suitesP->Iterate16Suite1()->iterate(
						ae->in_data, 
						0, 
						ae->output->width, 
						ae->output, 
						NULL,
						&bi, 
						reinterpret_cast<PF_Err(*)(void*, A_long, A_long, PF_Pixel16*, PF_Pixel16*)>(BoxBlurV16),
						ae->output));
				}
				break;

			case PF_PixelFormat_ARGB128:
				/*err = suites.IterateFloatSuite1()->iterate(in_data, 0, output->height, NULL, NULL, &info,
					TargetGradRadialIterator<PF_PixelFloat, float>,
					output);*/
				break;
			}
		}
		// ガウス近似：水平3回
		
	}
	return err;
}

//-------------------------------------------------------------------------------------------------
//レンダリングのメイン
/*
	SmartFXに対応していないホスト(After Effects7以前のもの)はこの関数が呼び出されて描画する
	この関数を書いておけば一応v6.5対応になる
*/
static PF_Err 
Render ( 
	PF_InData		*in_data,
	PF_OutData		*out_data,
	PF_ParamDef		*params[],
	PF_LayerDef		*output )
{

	PF_Err	err = PF_Err_NONE;
	PF_Handle		pixelTable = NULL;
	
	CFsAE ae(in_data,out_data,params,output,ID_NUM_PARAMS);
	err =ae.resultErr();
	if (!err){
		ParamInfo info;
		ERR(GetParams(&ae,&info));
		ERR(Exec(&ae,&info));
	}
	return err;
}
//-----------------------------------------------------------------------------------
/*
	SmartFX対応の場合、まずこの関数が呼ばれてパラメータの獲得を行う
*/
#if defined(SUPPORT_SMARTFX)
static PF_Err
PreRender(
	PF_InData			*in_data,
	PF_OutData			*out_data,
	PF_PreRenderExtra	*extraP)
{
	PF_Err		err 		= PF_Err_NONE;
	CFsAE ae(in_data,out_data,extraP,sizeof(ParamInfo),ID_NUM_PARAMS);
	err = ae.resultErr();
	if (!err){

		ParamInfo *infoP = reinterpret_cast<ParamInfo*>(ae.LockPreRenderData());
		if (infoP){
			ae.SetHostPreRenderData();
			ERR(GetParams(&ae,infoP));
			ERR(ae.UnSetPreRenderData());
			ae.UnlockPreRenderData();
		}else{
			err = PF_Err_OUT_OF_MEMORY;
		}
	}
	return err;
}
#endif
//-----------------------------------------------------------------------------------
#if defined(SUPPORT_SMARTFX)
static PF_Err
SmartRender(
	PF_InData				*in_data,
	PF_OutData				*out_data,
	PF_SmartRenderExtra		*extraP)
{
	PF_Err			err		= PF_Err_NONE,
					err2 	= PF_Err_NONE;

	CFsAE ae(in_data,out_data,extraP,ID_NUM_PARAMS);
	err = ae.resultErr();
	if (!err){
		ParamInfo *infoP = reinterpret_cast<ParamInfo*>(ae.LockPreRenderData());
		if (infoP){
			ERR(Exec(&ae,infoP));
			ERR2(ae.UnsetSmartRender());
			ae.UnlockPreRenderData();
		}else{
			err = PF_Err_OUT_OF_MEMORY;
		}
	}
	return err;
}
#endif

#include "Fs_Entry.h"
