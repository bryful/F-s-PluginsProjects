A batch script is included to do the extraction.

cd to this folder, and execute

CMD> extractzstd.bat