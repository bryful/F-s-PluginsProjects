#pragma once
#ifndef RGBShifter_H
#define RGBShifter_H

#include "..\_NFLib\AE_SDK.h"
#include "..\_NFLib\NF_Utils.h"



#endif