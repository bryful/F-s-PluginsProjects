﻿#include "Star.h"

// 指定された座標が画像内にあるかチェックし、ピクセルポインタを返すヘルパー
template <typename T>
inline T* GetPixelPtr(PF_EffectWorld* world, A_long x, A_long y) {
	if (x < 0 || x >= world->width || y < 0 || y >= world->height) return NULL;
	return reinterpret_cast<T*>((char*)world->data + (y * world->rowbytes) + (x * sizeof(T)));
}

// 線を伸ばすコアロジック
template <typename T>
static PF_Err DrawLineT(
	PF_EffectWorld* maskP,   // 抽出済みマスク
	PF_EffectWorld* outputP, // 合成先
	ParamInfo* infoP,
	int line_idx             // 0〜3 (Line1〜4)
) {
	PF_Err err = PF_Err_NONE;
	PF_FpLong max_chan = GetMaxChannel<T>();

	// このラインの設定
	PF_FpLong line_len = infoP->overall_length * infoP->lines[line_idx].len_per;
	PF_FpLong line_int = infoP->overall_intensity * infoP->lines[line_idx].int_per;
	PF_FpLong angle = infoP->overall_angle + infoP->lines[line_idx].angle_offset;
	if (line_len <= 0 || line_int <= 0) return err;
	// 方向ベクトル (0度は上方向 = 0時方向)
	PF_FpLong dx = sin(angle);
	PF_FpLong dy = -cos(angle);

	// 全ピクセルを走査
	for (A_long y = 0; y < maskP->height; y++) {
		for (A_long x = 0; x < maskP->width; x++) {
			T* srcP = GetPixelPtr<T>(maskP, x, y);
			if (srcP->alpha == 0) continue; // 光っていない場所はスキップ

			// 線の長さに沿って描画 (双方向)
			int i_len = (int)line_len;
			for (int i = -i_len; i <= i_len; i++) {
				if (i == 0) continue;

				// 浮動小数点精度の座標
				PF_FpLong fx = (PF_FpLong)x + (dx * i);
				PF_FpLong fy = (PF_FpLong)y + (dy * i);

				// 四辺の整数座標を取得
				A_long x1 = (A_long)floor(fx);
				A_long y1 = (A_long)floor(fy);
				A_long x2 = x1 + 1;
				A_long y2 = y1 + 1;

				// 小数点部分（重み）
				PF_FpLong wx2 = fx - x1;
				PF_FpLong wy2 = fy - y1;
				PF_FpLong wx1 = 1.0 - wx2;
				PF_FpLong wy1 = 1.0 - wy2;

				// 距離による減衰
				// 逆二乗的な減衰（中心を1.0、端を0.0にする）
				PF_FpLong dist_ratio = (PF_FpLong)abs(i) / line_len;
				PF_FpLong falloff = pow(1.0 - dist_ratio, 5.0); // 単純な2乗でも線形よりずっと綺麗です
				//PF_FpLong falloff = 1.0 - ((PF_FpLong)abs(i) / line_len);
				PF_FpLong amt = line_int * falloff;

				// 周辺4ピクセルに対して重み付け加算
				struct { A_long x; A_long y; PF_FpLong w; } samples[4] = {
					{x1, y1, wx1 * wy1},
					{x2, y1, wx2 * wy1},
					{x1, y2, wx1 * wy2},
					{x2, y2, wx2 * wy2}
				};

				for (int s = 0; s < 4; s++) {
					if (samples[s].w <= 0) continue;

					T* dstP = GetPixelPtr<T>(outputP, samples[s].x, samples[s].y);
					if (dstP) {
						PF_FpLong total_amt = amt * samples[s].w;
						PF_FpLong r2 = srcP->red* total_amt;
						PF_FpLong g2 = srcP->green * total_amt;
						PF_FpLong b2 = srcP->blue * total_amt;
						PF_FpLong a2 = srcP->alpha * total_amt;
						PF_FpLong r = (PF_FpLong)dstP->red + r2 - (PF_FpLong)dstP->red * r2/ max_chan;
						PF_FpLong g = (PF_FpLong)dstP->green + g2 - (PF_FpLong)dstP->green * g2/ max_chan;
						PF_FpLong b = (PF_FpLong)dstP->blue + b2 - (PF_FpLong)dstP->blue * b2/ max_chan;
						PF_FpLong a = (PF_FpLong)dstP->alpha + a2 - (PF_FpLong)dstP->alpha * a2 / max_chan;

						dstP->red = (typename PixelTraits<T>::channel_type)AE_CLAMP(r,0,max_chan);
						dstP->green = (typename PixelTraits<T>::channel_type)AE_CLAMP(g,0,max_chan);
						dstP->blue = (typename PixelTraits<T>::channel_type)AE_CLAMP(b,0,max_chan);
						dstP->alpha = (typename PixelTraits<T>::channel_type)AE_CLAMP(a,0,max_chan);
					}
				}
			}
		}
	}
	return err;
}
// 5. 4方向に対して線を伸ばす描画を実行
PF_Err DrawStar(NF_AE* ae, PF_EffectWorld *mask_world, ParamInfo* infoP) 
{
	PF_Err err = PF_Err_NONE;
	if (!err) {
		for (int i = 0; i < 4; i++) {
			switch (ae->pixelFormat()) {
			case PF_PixelFormat_ARGB128: 
				err = DrawLineT<PF_PixelFloat>(mask_world, ae->output, infoP, i); break;
			case PF_PixelFormat_ARGB64:  
				err = DrawLineT<PF_Pixel16>(mask_world, ae->output, infoP, i); break;
			case PF_PixelFormat_ARGB32:  
				err = DrawLineT<PF_Pixel8>(mask_world, ae->output, infoP, i); break;
			default:
				// サポートされていないピクセルフォーマット
				err = PF_Err_UNRECOGNIZED_PARAM_TYPE;
				return err;

			}
		}
	}
	return err;
}