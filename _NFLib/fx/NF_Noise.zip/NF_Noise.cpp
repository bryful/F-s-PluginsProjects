﻿#include "NF_Noise.h"

/**
 * 決定論的なハッシュ関数 (0.0 - 1.0)
 */
inline float hash_01(int x, int y, int seed) {
    uint32_t n = x * 374761393 + y * 668265263 + seed * 1103515245;
    n = (n ^ (n >> 13)) * 1274126177;
    return (float)(n & 0x7fffffff) / 2147483647.0f;
}

/**
 * バリューノイズ (3-6pxの粒感を作るための補間処理)
 */
float GetValueNoise(float x, float y, float size, int seed) {
    // 格子座標の特定
    int ix = (int)floor(x / size);
    int iy = (int)floor(y / size);

    // 格子内の相対位置 (0.0 - 1.0)
    float fx = (x / size) - (float)ix;
    float fy = (y / size) - (float)iy;

    // 四隅のハッシュ値
    float v00 = hash_01(ix, iy, seed);
    float v10 = hash_01(ix + 1, iy, seed);
    float v01 = hash_01(ix, iy + 1, seed);
    float v11 = hash_01(ix + 1, iy + 1, seed);

    // Smoothstepで補間を滑らかにする
    float ux = fx * fx * (3.0f - 2.0f * fx);
    float uy = fy * fy * (3.0f - 2.0f * fy);

    // バイリニア補間
    return (v00 * (1.0f - ux) + v10 * ux) * (1.0f - uy) +
        (v01 * (1.0f - ux) + v11 * ux) * uy;
}

typedef struct {
    PF_EffectWorld* output;
    float noise_size;
    float amount;
    float downsample_x;
    float downsample_y;
    int seed;
    bool is_color; // 追加
} NoiseData;
typedef struct {
    PF_EffectWorld* output;
    float noise_size;
    float amount;
    float downsample_x;
    float downsample_y;
    int seed;
    int type; // 0: 横方向(空電), 1: 縦方向(傷)
    PF_PixelFormat pixelFormat;
    bool is_color;
} BurstData;
/**
 * ビット深度に依存しない共通の加算・クランプ処理
 */
template <typename T>
inline void AddNoiseToPixel(T* pixel, int offset_int, float offset_float, PF_PixelFormat format) {
    if (format == PF_PixelFormat_ARGB32) {
        // 8bit: 0..255
        pixel->red = (A_u_char)AE_CLAMP((int)pixel->red + offset_int, 0, 255);
        pixel->green = (A_u_char)AE_CLAMP((int)pixel->green + offset_int, 0, 255);
        pixel->blue = (A_u_char)AE_CLAMP((int)pixel->blue + offset_int, 0, 255);
    }
    else if (format == PF_PixelFormat_ARGB64) {
        // 16bit: 0..32768
        pixel->red = (A_u_short)AE_CLAMP((int)pixel->red + offset_int, 0, 32768);
        pixel->green = (A_u_short)AE_CLAMP((int)pixel->green + offset_int, 0, 32768);
        pixel->blue = (A_u_short)AE_CLAMP((int)pixel->blue + offset_int, 0, 32768);
    }
    else if (format == PF_PixelFormat_ARGB128) {
        // 32bit Float: 0.0..1.0 (HDR対応ならクランプしない場合も多いですが、基本は0..1)
        pixel->red += offset_float;
        pixel->green += offset_float;
        pixel->blue += offset_float;
    }
}

/**
 * テンプレート版スキャンライン（カラー/モノクロ切り替え対応）
 */
template <typename T>
static PF_Err MyNoiseScanlineInPlaceT(
    void* refconPV,
    A_long thread_indexL,
    A_long i,
    A_long iterationsL)
{
    NoiseData* data = (NoiseData*)refconPV;
    A_long y = i;

    T* p = (T*)((char*)data->output->data + (y * data->output->rowbytes));
    int width = data->output->width;

    for (int x = 0; x < width; ++x) {
        float sample_x = (float)x / data->downsample_x;
        float sample_y = (float)y / data->downsample_y;

        float n_r, n_g, n_b;

        if (data->is_color) {
            // カラー：チャンネルごとに異なるシードでノイズを生成
            n_r = GetValueNoise(sample_x, sample_y, data->noise_size, data->seed);
            n_g = GetValueNoise(sample_x, sample_y, data->noise_size, data->seed + 100);
            n_b = GetValueNoise(sample_x, sample_y, data->noise_size, data->seed + 200);
        }
        else {
            // モノクロ：全チャンネル共通
            n_r = n_g = n_b = GetValueNoise(sample_x, sample_y, data->noise_size, data->seed);
        }

        // 共通のオフセット計算
        float off_r = (n_r * 2.0f) - 1.0f;
        float off_g = (n_g * 2.0f) - 1.0f;
        float off_b = (n_b * 2.0f) - 1.0f;

        if constexpr (std::is_same_v<T, PF_Pixel8>) {
            p->red = (A_u_char)AE_CLAMP((int)p->red + (int)(off_r * data->amount), 0, 255);
            p->green = (A_u_char)AE_CLAMP((int)p->green + (int)(off_g * data->amount), 0, 255);
            p->blue = (A_u_char)AE_CLAMP((int)p->blue + (int)(off_b * data->amount), 0, 255);
        }
        else if constexpr (std::is_same_v<T, PF_Pixel16>) {
            float amt16 = data->amount * 128.0f;
            p->red = (A_u_short)AE_CLAMP((int)p->red + (int)(off_r * amt16), 0, 32768);
            p->green = (A_u_short)AE_CLAMP((int)p->green + (int)(off_g * amt16), 0, 32768);
            p->blue = (A_u_short)AE_CLAMP((int)p->blue + (int)(off_b * amt16), 0, 32768);
        }
        else if constexpr (std::is_same_v<T, PF_PixelFloat>) {
            float amtF = data->amount / 255.0f;
            p->red += off_r * amtF;
            p->green += off_g * amtF;
            p->blue += off_b * amtF;
        }

        p++;
    }
    return PF_Err_NONE;
}
template <typename T>
static PF_Err MyBurstScanlineInPlaceT(
    void* refconPV,
    A_long thread_indexL,
    A_long i,
    A_long iterationsL)
{
    BurstData* data = (BurstData*)refconPV;
    A_long y = i;
    T* p = reinterpret_cast<T*>(reinterpret_cast<char*>(data->output->data) + (y * data->output->rowbytes));
    int width = data->output->width;

    // フレーム全体のシードから、発生させるブロックの数を決める
    // data->seed を使って、このフレームでいくつのブロックを置くか固定
    const int num_blocks = 8; // 8個程度のアクセント

    for (int k = 0; k < num_blocks; ++k) {
        // 各ブロックの形状・位置を決定
        // Y方向の範囲
        int b_y_start = static_cast<int>(hash_01(k, 10, data->seed) * data->output->height);
        int b_h = static_cast<int>(10 + hash_01(k, 20, data->seed) * 90); // 10-100px

        if (y < b_y_start || y >= b_y_start + b_h) continue;

        // X方向の範囲
        int b_x_start = static_cast<int>(hash_01(k, 30, data->seed) * width);
        int b_w = static_cast<int>(10 + hash_01(k, 40, data->seed) * 90); // 10-100px
        int b_x_end = b_x_start + b_w;

        // シフト量（左右に最大100px程度）
        int shift_x = static_cast<int>((hash_01(k, 50, data->seed) - 0.5f) * 200.0f * (data->amount / 100.0f));

        // 走査線ごとの微妙なズレ（これがないとただの画像移動に見えるので、1-2pxの隠し味）
        int micro_jitter = (hash_01(y, k, data->seed) > 0.5f) ? 1 : -1;

        for (int x = 0; x < width; ++x) {
            if (x >= b_x_start && x < b_x_end) {
                // サンプリング座標（横にずらす）
                int src_x = AE_CLAMP(x + shift_x + micro_jitter, 0, width - 1);

                // 元のバッファからずらした位置のピクセルを取得
                T* src_p = reinterpret_cast<T*>(reinterpret_cast<char*>(data->output->data) + (y * data->output->rowbytes)) + src_x;

                // そのまま上書き（ノイズ処理は一切なし）
                p[x] = *src_p;
            }
        }
    }
    return PF_Err_NONE;
}
/**
 * 補助関数：符号付き加算（減算対応）
 */

template <typename T>
inline void ApplyBurstColorT(T* p, float r, float g, float b, PF_PixelFormat format) {
    if constexpr (std::is_same_v<T, PF_Pixel8>) {
        p->red = (A_u_char)AE_CLAMP((int)p->red + (int)r, 0, 255);
        p->green = (A_u_char)AE_CLAMP((int)p->green + (int)g, 0, 255);
        p->blue = (A_u_char)AE_CLAMP((int)p->blue + (int)b, 0, 255);
    }
    else if constexpr (std::is_same_v<T, PF_Pixel16>) {
        p->red = (A_u_short)AE_CLAMP((int)p->red + (int)(r * 128.0f), 0, 32768);
        p->green = (A_u_short)AE_CLAMP((int)p->green + (int)(g * 128.0f), 0, 32768);
        p->blue = (A_u_short)AE_CLAMP((int)p->blue + (int)(b * 128.0f), 0, 32768);
    }
    else if constexpr (std::is_same_v<T, PF_PixelFloat>) {
        p->red += r / 255.0f; p->green += g / 255.0f; p->blue += b / 255.0f;
    }
}

static PF_Err NoiseImpl(
    PF_InData* in_data,
    PF_EffectWorld* worldP,
    PF_PixelFormat pixelFormat,
    AEGP_SuiteHandler* suitesP,
    PF_FpShort noise_size,
    PF_FpShort amount,
    A_long seed,
    A_Boolean is_color // 追加
)
{
    PF_Err err = PF_Err_NONE;
    NoiseData nData;
    nData.output = worldP;
    nData.noise_size = (float)noise_size;
    nData.amount = (float)amount;
    nData.seed = seed;
    nData.is_color = (is_color != 0); // 追加

    nData.downsample_x = (float)in_data->downsample_x.num / in_data->downsample_x.den;
    nData.downsample_y = (float)in_data->downsample_y.num / in_data->downsample_y.den;

    auto iterateSuite = suitesP->Iterate8Suite1();

    switch (pixelFormat) {
    case PF_PixelFormat_ARGB128:
        err = iterateSuite->iterate_generic(worldP->height, &nData, MyNoiseScanlineInPlaceT<PF_PixelFloat>);
        break;
    case PF_PixelFormat_ARGB64:
        err = iterateSuite->iterate_generic(worldP->height, &nData, MyNoiseScanlineInPlaceT<PF_Pixel16>);
        break;
    case PF_PixelFormat_ARGB32:
        err = iterateSuite->iterate_generic(worldP->height, &nData, MyNoiseScanlineInPlaceT<PF_Pixel8>);
        break;
    }

    float chance = hash_01(seed, 777, 0);
    if (chance > 0.0f) { // 10% の確率でアクセント発生
        BurstData bData;
        bData.output = worldP;
        bData.pixelFormat = pixelFormat;
        bData.is_color = is_color;
        bData.noise_size = (float)noise_size;
        bData.amount = (float)amount * 1.3f; // 少し強めに
        bData.seed = seed + 500;
        bData.downsample_x = (float)in_data->downsample_x.num / in_data->downsample_x.den;
        bData.downsample_y = (float)in_data->downsample_y.num / in_data->downsample_y.den;

        // 傷か空電かを決定
        bData.type = (hash_01(seed, 123, 456) > 0.5f) ? 1 : 0;

        //bData.type = 0;
        auto iterateSuite = suitesP->Iterate8Suite1();
        if (pixelFormat == PF_PixelFormat_ARGB128)
            iterateSuite->iterate_generic(worldP->height, &bData, MyBurstScanlineInPlaceT<PF_PixelFloat>);
        else if (pixelFormat == PF_PixelFormat_ARGB64)
            iterateSuite->iterate_generic(worldP->height, &bData, MyBurstScanlineInPlaceT<PF_Pixel16>);
        else
            iterateSuite->iterate_generic(worldP->height, &bData, MyBurstScanlineInPlaceT<PF_Pixel8>);
    }
    return err;
}
PF_Err Noise(
    PF_InData* in_data,
    PF_EffectWorld* worldP,
    PF_PixelFormat pixelFormat,
    AEGP_SuiteHandler* suitesP,
    PF_FpShort noise_size,
    PF_FpShort amount,
    A_long seed,
    A_Boolean is_color
)
{
    return NoiseImpl(in_data,worldP, pixelFormat, suitesP, noise_size, amount,seed,is_color);
}