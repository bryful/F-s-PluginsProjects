﻿#include "NF_DrawAALine.h"

/**
 * 汎用アンチエイリアス・ライン描画関数
 * T: PF_Pixel, PF_Pixel16, PF_PixelFloat
 * MAX_VAL: 255, 32768, 1.0f
 */

template <typename T, typename T_COMP, int MAX_VAL>
void DrawAALineT(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    T col1, T col2,
    float startWeight, float endWeight)
{
    float maxW = max(startWeight, endWeight) + 2.0f;
    int minX = max(0, (int)(min(x0, x1) - maxW));
    int maxX = min((int)output->width - 1, (int)(max(x0, x1) + maxW));
    int minY = max(0, (int)(min(y0, y1) - maxW));
    int maxY = min((int)output->height - 1, (int)(max(y0, y1) + maxW));

    float dx = x1 - x0;
    float dy = y1 - y0;
    float l2 = dx * dx + dy * dy;
    float inv_l2 = (l2 == 0) ? 0 : 1.0f / l2;

    // 事前に範囲外をチェック
    if (maxX < minX || maxY < minY) return;

    for (int y = minY; y <= maxY; y++) {
        T* dstP = (T*)((char*)output->data + (y * output->rowbytes) + (minX * sizeof(T)));
        float py0 = y - y0;

        for (int x = minX; x <= maxX; x++, dstP++) {
            float px0 = x - x0;

            // 線分上の射影係数 t の計算 (内積 / l2)
            float t = (px0 * dx + py0 * dy) * inv_l2;
            t = std::clamp(t, 0.0f, 1.0f);

            // 最短距離の二乗を計算 (sqrtを避ける)
            float projX = x0 + t * dx;
            float projY = y0 + t * dy;
            float dx_p = x - projX;
            float dy_p = y - projY;
            float distSq = dx_p * dx_p + dy_p * dy_p;

            float currentWeight = startWeight + (endWeight - startWeight) * t;
            float halfW = currentWeight * 0.5f;
            float edge0 = halfW + 0.5f;
            float edge1 = max(0.0f, halfW - 0.5f);

            // 早期判定
            if (distSq > edge0 * edge0) continue;

            float intensity;
            if (distSq < edge1 * edge1) {
                intensity = 1.0f; // 完全に内側
            }
            else {
                // 境界付近のみ sqrt を計算
                intensity = std::clamp((edge0 - std::sqrt(distSq)) / (edge0 - edge1), 0.0f, 1.0f);
            }

            // --- ブレンディング処理 ---
            float r = (1.0f - t) * col1.red + t * col2.red;
            float g = (1.0f - t) * col1.green + t * col2.green;
            float b = (1.0f - t) * col1.blue + t * col2.blue;
            float a = (1.0f - t) * col1.alpha + t * col2.alpha;

            float src_alpha = (a / (float)MAX_VAL) * intensity;

            // 32bit(float)の場合は min/max のリミッター不要だが、汎用性のために維持
            dstP->red = (T_COMP)min((float)MAX_VAL, dstP->red * (1.0f - src_alpha) + r * src_alpha);
            dstP->green = (T_COMP)min((float)MAX_VAL, dstP->green * (1.0f - src_alpha) + g * src_alpha);
            dstP->blue = (T_COMP)min((float)MAX_VAL, dstP->blue * (1.0f - src_alpha) + b * src_alpha);
            dstP->alpha = (T_COMP)max((float)dstP->alpha, (float)(a * intensity));
        }
    }
}

void DrawAALine8(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    PF_Pixel col1,
    PF_Pixel col2,
    float startWeight, float endWeight)
{
    DrawAALineT<PF_Pixel, A_u_char, PF_MAX_CHAN8>(
        output, x0, y0, x1, y1, col1, col2, startWeight, endWeight);
}
void DrawAALine16(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    PF_Pixel16 col1,
    PF_Pixel16 col2,
    float startWeight, float endWeight)
{
    DrawAALineT<PF_Pixel16, A_u_short, PF_MAX_CHAN16>(
        output, x0, y0, x1, y1, col1, col2, startWeight, endWeight);
}
void DrawAALine32(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    PF_PixelFloat col1,
    PF_PixelFloat col2,
    float startWeight, float endWeight)
{
    DrawAALineT<PF_PixelFloat, PF_FpShort, 1>(
        output, x0, y0, x1, y1, col1, col2, startWeight, endWeight);
}

// ***************************************************************************************
// Iterate Suite用のワーカー関数（各ピクセル形式ごとに明示的に定義）

template <typename T>
struct LineRefData {
    float x0, y0, x1, y1;
    T col1;
    T col2;
    float startWeight, endWeight;
    float dx, dy, l2, inv_l2;
    float max_val;
};

// テンプレート化されたワーカー関数の実装
template <typename T, typename T_COMP>
static PF_Err LineWorkerT(
    void* refcon,
    A_long x,
    A_long y,
    T* in,
    T* out)
{
    LineRefData<T>* data = (LineRefData<T>*)refcon;
    T* dstP = out;

    float px0 = (float)x - data->x0;
    float py0 = (float)y - data->y0;

    float t = (px0 * data->dx + py0 * data->dy) * data->inv_l2;
    t = std::clamp(t, 0.0f, 1.0f);

    float projX = data->x0 + t * data->dx;
    float projY = data->y0 + t * data->dy;
    float distSq = ((float)x - projX) * ((float)x - projX) + ((float)y - projY) * ((float)y - projY);

    float currentWeight = data->startWeight + (data->endWeight - data->startWeight) * t;
    float halfW = currentWeight * 0.5f;
    float edge0 = halfW + 0.5f;
    float edge1 = max(0.0f, halfW - 0.5f);

    if (distSq < edge0 * edge0) {
        float intensity = (distSq < edge1 * edge1) ? 1.0f :
            std::clamp((edge0 - std::sqrt(distSq)) / (edge0 - edge1), 0.0f, 1.0f);

        float r = (1.0f - t) * data->col1.red + t * data->col2.red;
        float g = (1.0f - t) * data->col1.green + t * data->col2.green;
        float b = (1.0f - t) * data->col1.blue + t * data->col2.blue;
        float a = (1.0f - t) * data->col1.alpha + t * data->col2.alpha;

        float src_alpha = (a / data->max_val) * intensity;

        dstP->red = (T_COMP)min(data->max_val, dstP->red * (1.0f - src_alpha) + r * src_alpha);
        dstP->green = (T_COMP)min(data->max_val, dstP->green * (1.0f - src_alpha) + g * src_alpha);
        dstP->blue = (T_COMP)min(data->max_val, dstP->blue * (1.0f - src_alpha) + b * src_alpha);
        dstP->alpha = (T_COMP)max((float)dstP->alpha, a * intensity);
    }
    return PF_Err_NONE;
}

// 薄いラッパー関数（関数ポインタの型を合わせるため）
PF_Err LineWorker8(void* refcon, A_long x, A_long y, PF_Pixel* in, PF_Pixel* out) {
    return LineWorkerT<PF_Pixel, A_u_char>(refcon, x, y, in, out);
}

PF_Err LineWorker16(void* refcon, A_long x, A_long y, PF_Pixel16* in, PF_Pixel16* out) {
    return LineWorkerT<PF_Pixel16, A_u_short>(refcon, x, y, in, out);
}

PF_Err LineWorker32(void* refcon, A_long x, A_long y, PF_PixelFloat* in, PF_PixelFloat* out) {
    return LineWorkerT<PF_PixelFloat, PF_FpShort>(refcon, x, y, in, out);
}

PF_Err DrawAA_Line(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    PF_PixelFormat pixelFormat,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_Pixel col1,
    PF_Pixel col2,
    float startWeight, float endWeight)
{
    PF_Err err = PF_Err_NONE;

    // 描画矩形を制限して効率化
    float maxW = max(startWeight, endWeight) + 2.0f;
    PF_Rect draw_rect;
    draw_rect.left = (short)max(0, (int)(min(x0, x1) - maxW));
    draw_rect.top = (short)max(0, (int)(min(y0, y1) - maxW));
    draw_rect.right = (short)min((int)output->width, (int)(max(x0, x1) + maxW));
    draw_rect.bottom = (short)min((int)output->height, (int)(max(y0, y1) + maxW));

    switch (pixelFormat)
    {
        case PF_PixelFormat_ARGB128:
        {
            LineRefData<PF_PixelFloat> data32;
            data32.x0 = x0; data32.y0 = y0; data32.x1 = x1; data32.y1 = y1;
            // 8bitカラーを32bitに変換
			data32.col1 = NF_Pixel8To32(col1);
            data32.col2 = NF_Pixel8To32(col2);
            data32.startWeight = startWeight; data32.endWeight = endWeight;
            data32.dx = x1 - x0; data32.dy = y1 - y0;
            data32.l2 = data32.dx * data32.dx + data32.dy * data32.dy;
            data32.inv_l2 = (data32.l2 == 0) ? 0 : 1.0f / data32.l2;
            data32.max_val = 1.0f;

            ERR(suitesP->IterateFloatSuite2()->iterate(
                in_dataP,
                0,
                draw_rect.bottom - draw_rect.top,
                NULL,
                &draw_rect,
                (void*)&data32,
                LineWorker32,
                output));
            break;
        }
        case PF_PixelFormat_ARGB64:
        {
            LineRefData<PF_Pixel16> data16;
            data16.x0 = x0; data16.y0 = y0; data16.x1 = x1; data16.y1 = y1;
            // 8bitカラーを16bitに変換
            data16.col1 = NF_Pixel8To16(col1);
            data16.col2 = NF_Pixel8To16(col2);
            data16.startWeight = startWeight; data16.endWeight = endWeight;
            data16.dx = x1 - x0; data16.dy = y1 - y0;
            data16.l2 = data16.dx * data16.dx + data16.dy * data16.dy;
            data16.inv_l2 = (data16.l2 == 0) ? 0 : 1.0f / data16.l2;
            data16.max_val = PF_MAX_CHAN16;

            ERR(suitesP->Iterate16Suite2()->iterate(
                in_dataP,
                0,
                draw_rect.bottom - draw_rect.top,
                NULL,
                &draw_rect,
                (void*)&data16,
                LineWorker16,
                output));
            break;
        }
        case PF_PixelFormat_ARGB32:
        {
            LineRefData<PF_Pixel> data8;
            data8.x0 = x0; data8.y0 = y0; data8.x1 = x1; data8.y1 = y1;
            data8.col1 = col1; data8.col2 = col2;
            data8.startWeight = startWeight; data8.endWeight = endWeight;
            data8.dx = x1 - x0; data8.dy = y1 - y0;
            data8.l2 = data8.dx * data8.dx + data8.dy * data8.dy;
            data8.inv_l2 = (data8.l2 == 0) ? 0 : 1.0f / data8.l2;
            data8.max_val = 255.0f;

            ERR(suitesP->Iterate8Suite2()->iterate(
                in_dataP,
                0,
                draw_rect.bottom - draw_rect.top,
                NULL,
                &draw_rect,
                (void*)&data8,
                LineWorker8,
                output));
            break;
        }
    }
    return err;
}
// ------------------
PF_Err DrawAA_Line32(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_PixelFloat col1,
    PF_PixelFloat col2,
    float startWeight, float endWeight)
{
    PF_Err err = PF_Err_NONE;

    // 描画矩形を制限して効率化
    float maxW = max(startWeight, endWeight) + 2.0f;
    PF_Rect draw_rect;
    draw_rect.left = (short)max(0, (int)(min(x0, x1) - maxW));
    draw_rect.top = (short)max(0, (int)(min(y0, y1) - maxW));
    draw_rect.right = (short)min((int)output->width, (int)(max(x0, x1) + maxW));
    draw_rect.bottom = (short)min((int)output->height, (int)(max(y0, y1) + maxW));
    LineRefData<PF_PixelFloat> data32;
    data32.x0 = x0; data32.y0 = y0; data32.x1 = x1; data32.y1 = y1;
    // 8bitカラーを32bitに変換
    data32.col1 = col1;
    data32.col2 = col2;
    data32.startWeight = startWeight; data32.endWeight = endWeight;
    data32.dx = x1 - x0; data32.dy = y1 - y0;
    data32.l2 = data32.dx * data32.dx + data32.dy * data32.dy;
    data32.inv_l2 = (data32.l2 == 0) ? 0 : 1.0f / data32.l2;
    data32.max_val = 1.0f;

    ERR(suitesP->IterateFloatSuite2()->iterate(
        in_dataP,
        0,
        draw_rect.bottom - draw_rect.top,
        NULL,
        &draw_rect,
        (void*)&data32,
        LineWorker32,
        output));
    return err;
}
// ***************************************************************************************
PF_Err DrawAA_Line16(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_Pixel16 col1,
    PF_Pixel16 col2,
    float startWeight, float endWeight)
{
    PF_Err err = PF_Err_NONE;

    // 描画矩形を制限して効率化
    float maxW = max(startWeight, endWeight) + 2.0f;
    PF_Rect draw_rect;
    draw_rect.left = (short)max(0, (int)(min(x0, x1) - maxW));
    draw_rect.top = (short)max(0, (int)(min(y0, y1) - maxW));
    draw_rect.right = (short)min((int)output->width, (int)(max(x0, x1) + maxW));
    draw_rect.bottom = (short)min((int)output->height, (int)(max(y0, y1) + maxW));
    LineRefData<PF_Pixel16> data16;
    data16.x0 = x0; data16.y0 = y0; data16.x1 = x1; data16.y1 = y1;
    // 8bitカラーを16bitに変換
    data16.col1 = col1;
    data16.col2 = col2;
    data16.startWeight = startWeight; data16.endWeight = endWeight;
    data16.dx = x1 - x0; data16.dy = y1 - y0;
    data16.l2 = data16.dx * data16.dx + data16.dy * data16.dy;
    data16.inv_l2 = (data16.l2 == 0) ? 0 : 1.0f / data16.l2;
    data16.max_val = PF_MAX_CHAN16;

    ERR(suitesP->Iterate16Suite2()->iterate(
        in_dataP,
        0,
        draw_rect.bottom - draw_rect.top,
        NULL,
        &draw_rect,
        (void*)&data16,
        LineWorker16,
        output));
    return err;
}
PF_Err DrawAA_Line8(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_Pixel col1,
    PF_Pixel col2,
    float startWeight, float endWeight)
{
    PF_Err err = PF_Err_NONE;

    // 描画矩形を制限して効率化
    float maxW = max(startWeight, endWeight) + 2.0f;
    PF_Rect draw_rect;
    draw_rect.left = (short)max(0, (int)(min(x0, x1) - maxW));
    draw_rect.top = (short)max(0, (int)(min(y0, y1) - maxW));
    draw_rect.right = (short)min((int)output->width, (int)(max(x0, x1) + maxW));
    draw_rect.bottom = (short)min((int)output->height, (int)(max(y0, y1) + maxW));
    LineRefData<PF_Pixel> data8;
    data8.x0 = x0; data8.y0 = y0; data8.x1 = x1; data8.y1 = y1;
    data8.col1 = col1; data8.col2 = col2;
    data8.startWeight = startWeight; data8.endWeight = endWeight;
    data8.dx = x1 - x0; data8.dy = y1 - y0;
    data8.l2 = data8.dx * data8.dx + data8.dy * data8.dy;
    data8.inv_l2 = (data8.l2 == 0) ? 0 : 1.0f / data8.l2;
    data8.max_val = 255.0f;

    ERR(suitesP->Iterate8Suite2()->iterate(
        in_dataP,
        0,
        draw_rect.bottom - draw_rect.top,
        NULL,
        &draw_rect,
        (void*)&data8,
        LineWorker8,
        output));
    return err;
}