﻿#pragma once
#pragma once
#ifndef NF_DRAW_AA_LINE_H
#define NF_DRAW_AA_LINE_H


#include "AEConfig.h" 
#include "entry.h"

#ifdef AE_OS_WIN
#include "string.h"
#endif
#include "AE_Effect.h"
#include "AE_EffectCB.h"
#include "AE_EffectCBSuites.h"
#include "AE_Macros.h"
#include "AEGP_SuiteHandler.h"
#include "String_Utils.h"
#include "Param_Utils.h"
#include "Smart_Utils.h"
#include "AE_GeneralPlug.h"

#include "AEFX_SuiteHelper.h"
#define refconType void*

#include "..\NF_Utils.h"
#include <vector>
#include <cmath>
#include <algorithm>

template <typename T, typename T_COMP, int MAX_VAL>
void DrawAALineT(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    T col1, T col2,
    float startWeight, float endWeight);
void DrawAALine8(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    PF_Pixel col1,
    PF_Pixel col2,
    float startWeight, float endWeight);
void DrawAALine16(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    PF_Pixel16 col1,
    PF_Pixel16 col2,
    float startWeight, float endWeight);
void DrawAALine32(
    PF_EffectWorld* output,
    float x0, float y0, float x1, float y1,
    PF_PixelFloat col1,
    PF_PixelFloat col2,
    float startWeight, float endWeight);

PF_Err DrawAA_Line32(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_PixelFloat col1,
    PF_PixelFloat col2,
    float startWeight, float endWeight);
PF_Err DrawAA_Line16(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_Pixel16 col1,
    PF_Pixel16 col2,
    float startWeight, float endWeight);
PF_Err DrawAA_Line8(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_Pixel col1,
    PF_Pixel col2,
    float startWeight, float endWeight);

PF_Err DrawAA_Line(
    PF_InData* in_dataP,
    PF_EffectWorld* output,
    PF_PixelFormat pixelFormat,
    AEGP_SuiteHandler* suitesP,
    float x0, float y0, float x1, float y1,
    PF_Pixel col1,
    PF_Pixel col2,
    float startWeight, float endWeight);


#endif // NF_DRAWWORLD_H