﻿/*
	ｃ.exe ＜アイコン名＞　＜ターゲットフォルダのフルパス＞
	
	アイコンはSetFolderIcon.exeのあるフォルダになるiconsフォルダの中にあるものです。
	
	エラーの時のみ"error!"という文字列を返します
	
	アイコン名を"delete"にすると、カスタムアイコンを削除します。
	（つまりdelete.icoって名前のアイコンは登録できません）
*/

folderObj = Folder.selectDialog("Select");

var ret = system.callSystem("SetFolderIcon.exe"+ " " +"Cut_Blue" + " \"" + folderObj.fsName+"\"");
if ( ret !=""){
	alert(ret);
}else{
	alert("成功");

}
