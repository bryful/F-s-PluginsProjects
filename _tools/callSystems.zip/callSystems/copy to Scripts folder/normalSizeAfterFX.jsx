﻿/*
	NormalSizeAfterFX.exe 
	引数なし
	
	実行すれば、ウィンドウが最大化・最小化が解除される
	
	内部で"WindosStatusAfterFX.exe normal"を呼び出している
*/
system.callSystem("NormalSizeAfterFX.exe");

