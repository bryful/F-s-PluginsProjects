﻿/*
	minSizeAfterFX.exe 
	引数なし
	
	実行すれば、ウィンドウが最小化される

	内部で"WindosStatusAfterFX.exe min"を呼び出している
	
*/
system.callSystem("minSizeAfterFX.exe");

