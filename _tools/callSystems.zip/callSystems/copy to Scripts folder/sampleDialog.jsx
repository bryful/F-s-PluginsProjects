﻿/*
	SampleDialog.exe 
	
	ダイアログのサンプル
*/

var foo = "ダイアログのサンプル";
var ret = system.callSystem("SampleDialog.exe" + " " + foo);
if ( ret !=""){
	alert(ret);
}
