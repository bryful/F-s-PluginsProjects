﻿/*
	SpecialFolder.exe 
	
	特殊フォルダのフルパスを返す。
	
	引数には以下のものが選べる
	
	Desktop
	MyMusic
	MyPictures
	System
	MyDocuments
	ProgramFiles
	ProgramFilesX86
	MyVideos
	Windows
*/

var ret = system.callSystem("SpecialFolder.exe MyDocuments");
if ( ret !=""){
	alert(ret);
}
