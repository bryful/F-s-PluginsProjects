﻿/*
	GetClipboard.exe 
	引数なし
	
	成功すれば、クリップボードの中身が出力される。
*/
var s = system.callSystem("GetClipboard.exe");
alert(s);
