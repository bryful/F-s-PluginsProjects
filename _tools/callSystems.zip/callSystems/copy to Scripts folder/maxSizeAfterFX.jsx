﻿/*
	MaxSizeAfterFX.exe 
	引数なし
	
	実行すれば、ウィンドウが最大化される

	内部で"WindosStatusAfterFX.exe max"を呼び出している
	
*/
system.callSystem("MaxSizeAfterFX.exe");

