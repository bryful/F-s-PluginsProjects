﻿/*
	SelectFolder.exe 
	
	フォルダ選択ダイアログを表示
	前回選んだパスを保存している。
*/

var ret = system.callSystem("SelectFolder.exe" );
if ( ret !=""){
	alert(ret);
}
