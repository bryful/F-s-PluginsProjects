﻿/*
	CreateShortcut.exe ＜ショートカットの元になるファイルのフルパス＞ [ショートカットの保存先のフォルダのフルパス」
	第２引数を省略するとデスクトップにショートカットが保存される
	渡すパスは、"C:\Program Files"のスタイルで。
	
	成功すれば、ショートカットのフルパスが出力される。
*/
fileObj = File.openDialog("適当なファイルを選ぶ","");

if ( fileObj != null){
	//ファイル名を渡すときには""でくくる
	var s = system.callSystem("CreateShortcut.exe" + " \"" + fileObj.fsName + "\"");
	alert(s);
}
