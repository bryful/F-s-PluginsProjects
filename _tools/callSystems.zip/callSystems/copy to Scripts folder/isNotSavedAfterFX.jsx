﻿/*
	IsNotSavedAfterFX.exe 
	引数なし
	
	After EffectsのProjectファイルが修正されていて未保存の場合"true"
	それ以外は"false"の文字列を出力
*/
var ret = system.callSystem("IsNotSavedAfterFX.exe");
alert(ret);
