﻿
var err = system.callSystem("ProcessStart.exe \"notepad.exe\"");
if (err !="") alert("error!");

