﻿function callEdit(p)
{
	var nowDir = Folder.current;

	var targetProperty = null;
	var tempFile = new File("temp.jsx");
	var exeFile = new File("callEditor.exe");
	if ( exeFile.exists == false){
		alert("callEditor.exeが見つかりません！");s
	}else{
		alert(exeFile.fsName);
	}
	

	function buildPalette(me)
	{	//---------------
		this.winObj = ( me instanceof Panel) ? me : new Window("palette", "Form1", [176, 232, 176+197, 232+56]);
		this.btn = this.winObj.add("button", [12, 12, 12+171, 12+29], "Expressionを外部エディタで開く");
		//---------------
		if ( ( me instanceof Panel) == false){ this.winObj.center(); this.winObj.show(); }
	}

	var dlg = new buildPalette(p);

	
	function err(s)
	{
		alert(s + ":レイヤのプロパティを一つだけ選択してください。");
	}

	function exec()
	{
		var activeComp = app.project.activeItem;
		if ( (activeComp!=null)&&(activeComp instanceof CompItem) )
		{
			var selectedLayers = activeComp.selectedLayers;
			
			if ( selectedLayers.length ==1)
			{
				var sp = selectedLayers[0].selectedProperties;
				if (sp.length==1)
				{
					targetProperty = sp[0];
				}else{
					err("1");
				}
			}else{
				err("2");
			}
		}

		if (targetProperty==null){
			return false;
		}
		if (targetProperty.canSetExpression == false){
			alert(targetProperty.name + ":Expressionに未対応です。");
			return false;
		}
		if (targetProperty.expressionEnabled == false)
		{
			targetProperty.expressionEnabled = true;
		}
		var s = targetProperty.expression;
		
		var bp = Folder.current;
		Folder.current = nowDir;
		tempFile.open("w");
		tempFile.write(s);
		tempFile.close();
		var ref = system.callSystem("\"" + exeFile.fsName + "\"" + " \"" + tempFile.fsName + "\"");
		if( ref != "")
		{
			targetProperty.expression = ref;
			targetProperty.expressionEnabled = true;
		}
		if ( tempFile.exists == true)
		{
			tempFile.remove();
		}
		Folder.current = bp;
	}
	dlg.btn.onClick = exec;
}

var callEditObj = new callEdit(this);

