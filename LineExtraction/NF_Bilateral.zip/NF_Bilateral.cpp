﻿#include "LineExtraction.h"

// 内部用コンテキスト
struct BilateralInfo {
    PF_EffectWorld* src;
    PF_EffectWorld* dst;
    BilateralContext* ctx;
};

// --- 輝度算出ヘルパー (実体を先に定義) ---

template <typename T>
inline float GetLuma01(const T* p);

template <>
inline float GetLuma01<PF_Pixel8>(const PF_Pixel8* p) {
	return (0.299f * (float)p->red + 0.587f * (float)p->green + 0.114f * (float)p->blue) / 255.0f;
}

template <>
inline float GetLuma01<PF_Pixel16>(const PF_Pixel16* p) {
    return (0.299f * (float)p->red + 0.587f * (float)p->green + 0.114f * (float)p->blue) / 32768.0f;
}

template <>
inline float GetLuma01<PF_PixelFloat>(const PF_PixelFloat* p) {
    return (0.299f * p->red + 0.587f * p->green + 0.114f * p->blue);
}

// --- 重みテーブルの初期化 ---

void SetupBilateralContext(BilateralContext* ctx, int radius, float sigma_s, float sigma_r) {
    ctx->radius = radius;
    ctx->kernel_size = radius * 2 + 1;

    // Spatial LUT (距離の重み)
    for (int y = -radius; y <= radius; y++) {
        for (int x = -radius; x <= radius; x++) {
            ctx->spatial_lut[(y + radius) * ctx->kernel_size + (x + radius)] =
                expf(-(float)(x * x + y * y) / (2 * sigma_s * sigma_s));
        }
    }

    // Range LUT (輝度差の重み - 8bit高速化用)
    float r_divisor = 2.0f * sigma_r * sigma_r + 0.0001f;
    for (int i = 0; i < 256; i++) {
        float diff = (float)i / 255.0f;
        ctx->range_lut[i] = expf(-(diff * diff) / r_divisor);
    }
}

// --- フィルタ本体 (Template) ---

template <typename T, typename U, int MAX_VAL_INT>
static PF_Err BilateralFilterGeneric(
    void* refcon,
    A_long thread_idx,
    A_long iterNum,
    A_long iterTotal)
{
    BilateralInfo* info = reinterpret_cast<BilateralInfo*>(refcon);
    BilateralContext* ctx = info->ctx;

    A_long y = iterNum;
    T* src_row_ptr = reinterpret_cast<T*>((uint8_t*)info->src->data + (y * info->src->rowbytes));
    T* dst_row_ptr = reinterpret_cast<T*>((uint8_t*)info->dst->data + (y * info->dst->rowbytes));

    float r_divisor = 2.0f * ctx->sigma_r * ctx->sigma_r + 0.0001f;

    for (A_long x = 0; x < info->src->width; x++) {
        T* center_pixel = &src_row_ptr[x];
        float center_luma = GetLuma01(center_pixel);

        float sum_r = 0, sum_g = 0, sum_b = 0, sum_w = 0;

        for (int ky = -ctx->radius; ky <= ctx->radius; ky++) {
            A_long cur_y = AE_CLAMP(y + ky, 0, info->src->height - 1);
            T* kernel_row_ptr = reinterpret_cast<T*>((uint8_t*)info->src->data + (cur_y * info->src->rowbytes));

            for (int kx = -ctx->radius; kx <= ctx->radius; kx++) {
                A_long cur_x = AE_CLAMP(x + kx, 0, info->src->width - 1);
                T* p = &kernel_row_ptr[cur_x];

                float w_s = ctx->spatial_lut[(ky + ctx->radius) * ctx->kernel_size + (kx + ctx->radius)];

                float neighbor_luma = GetLuma01(p);
                float luma_diff = center_luma - neighbor_luma;
                float w_r = 1.0f;
                if constexpr (MAX_VAL_INT == 255) {
                    // 8bitは高速なLUT参照
                    int diff_idx = static_cast<int>(fabsf(luma_diff) * 255.0f + 0.5f);
                    w_r = ctx->range_lut[AE_CLAMP(diff_idx, 0, 255)];
                }
                else {
                    // 16/32bitは直接計算 (r_divisorは SetupBilateralContext と同じ定義を使用)
                    float r_v = 2.0f * ctx->sigma_r * ctx->sigma_r + 0.00001f;
                    w_r = expf(-(luma_diff * luma_diff) / r_v);
                }

                float weight = w_s * w_r;

                sum_r += (float)p->red * weight;
                sum_g += (float)p->green * weight;
                sum_b += (float)p->blue * weight;
                sum_w += weight;
            }
        }

        if (sum_w > 0.0f) {
            float inv_w = 1.0f / sum_w;
            float r = sum_r * inv_w;
            float g = sum_g * inv_w;
            float b = sum_b * inv_w;

            if constexpr (MAX_VAL_INT > 0) {
                // 8bit / 16bit 整数型への代入
                // 0.5fを足して四捨五入し、int型に明示的に落としてからU(A_u_char等)にキャスト
                dst_row_ptr[x].red = static_cast<U>(static_cast<int>(AE_CLAMP(r + 0.5f, 0.0f, static_cast<float>(MAX_VAL_INT))));
                dst_row_ptr[x].green = static_cast<U>(static_cast<int>(AE_CLAMP(g + 0.5f, 0.0f, static_cast<float>(MAX_VAL_INT))));
                dst_row_ptr[x].blue = static_cast<U>(static_cast<int>(AE_CLAMP(b + 0.5f, 0.0f, static_cast<float>(MAX_VAL_INT))));
            }
            else {
                // 32bit Float への代入 (U は float なので直接代入可能)
                dst_row_ptr[x].red = r;
                dst_row_ptr[x].green = g;
                dst_row_ptr[x].blue = b;
            }
        }
        dst_row_ptr[x].alpha = center_pixel->alpha;
    }
    return PF_Err_NONE;
}

// --- 実行関数 ---

PF_Err PF_BilateralExec(NF_AE* ae, ParamInfo* infoP)
{
    PF_Err err = PF_Err_NONE;

    // 重みテーブルの準備
    BilateralContext ctx;
    SetupBilateralContext(
        &ctx,
        infoP->bilateralCtx.radius,
        infoP->bilateralCtx.sigma_s,
        infoP->bilateralCtx.sigma_r);

    BilateralInfo info;
    info.src = ae->input;
    info.dst = ae->output;
    info.ctx = &ctx;

    // 全てのビット深度で Iterate8Suite2()->iterate_generic を使用する
    // ただし、関数内で扱うピクセル型はビット深度に合わせる
    switch (ae->pixelFormat())
    {
    case PF_PixelFormat_ARGB128: // 32-bit Float
        err = ae->suitesP->Iterate8Suite2()->iterate_generic(
            ae->output->height,
            &info,
            BilateralFilterGeneric<PF_PixelFloat, float, 0>);
        break;

    case PF_PixelFormat_ARGB64:  // 16-bit
        err = ae->suitesP->Iterate8Suite2()->iterate_generic(
            ae->output->height,
            &info,
            BilateralFilterGeneric<PF_Pixel16, A_u_short, 32768>);
        break;

    case PF_PixelFormat_ARGB32:  // 8-bit
        err = ae->suitesP->Iterate8Suite2()->iterate_generic(
            ae->output->height,
            &info,
            BilateralFilterGeneric<PF_Pixel8, A_u_char, 255>);
        break;

    default:
        err = PF_Err_UNRECOGNIZED_PARAM_TYPE;
        break;
    }

    return err;
}